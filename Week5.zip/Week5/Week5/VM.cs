﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Week5
{
    class VM :INotifyPropertyChanged
    {
        const string FILENAME="filename.txt";
        const string DIRNAME = "PROG8010";

        const int TOTAL_PCT = 100;
        string _initialOrg;
        string _pctIncrease;
        string _noOfDays;

        ObservableCollection<Data> _myList =  new ObservableCollection<Data>();
        public event PropertyChangedEventHandler PropertyChanged;
       public ObservableCollection<Data> MyList
        {
            get { return _myList; }
            set { _myList = value; OnPropertyChanged(); }
        }

        public string InitialOrganism
        {
            get { return _initialOrg; }
            set { _initialOrg = value; OnPropertyChanged(); }

        }

        public string PctIncrease
        {
            get { return _pctIncrease; }
            set { _pctIncrease = value; OnPropertyChanged(); }

        }

        public string NoOfDays
        {
            get { return _noOfDays; }
            set { _noOfDays = value; OnPropertyChanged(); }

        }

        public void Save()
        {
           string path=  System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string fullpath = Path.Combine(path, DIRNAME);
            Directory.CreateDirectory(fullpath);

            string fullname = Path.Combine(fullpath, FILENAME);
         
            StreamWriter sw = File.AppendText(fullname);

            foreach (Data d in MyList)
            {
             
                sw.Write(" ");
                sw.WriteLine(d.ToString());
            }

            sw.Close();
            MessageBox.Show("Text Saved Successfully");
        }
     

        public ObservableCollection<Data> Calculate()
        {
            uint organism;
            float increase;
            uint days;
            try
            {

                organism = uint.Parse(_initialOrg);
                days = uint.Parse(_noOfDays);
                increase = float.Parse(_pctIncrease);
                for (int i = 1; i <= days; i++)
                {
                    organism = (uint)(organism * (1 + increase / TOTAL_PCT));
                    Data d = new Data();
                    d.Value1 = organism;
                    _myList.Add(d);
                }

            }
            catch
            {
                 MessageBox.Show("Please enter acceptable values");
            }

            return _myList;
        }




        protected void OnPropertyChanged([CallerMemberName] string name="")
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
